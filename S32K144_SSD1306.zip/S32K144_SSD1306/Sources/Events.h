/*
** ===================================================================
INFO: empty Drivers\common\GeneralDamage.inc file
**     Description :
**         Event called in the event of GetLCD() method called.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/

