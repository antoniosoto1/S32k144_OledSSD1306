#ifndef __LEDB_CONFIG_H
#define __LEDB_CONFIG_H

/* no configuration supported yet */

#endif /* __LEDB_CONFIG_H */
