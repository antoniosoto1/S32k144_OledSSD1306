#ifndef __FDisp1_CONFIG_H
#define __FDisp1_CONFIG_H

/* no configuration supported yet */

#endif /* __FDisp1_CONFIG_H */
