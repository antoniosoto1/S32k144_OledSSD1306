#ifndef __GFONT1_CONFIG_H
#define __GFONT1_CONFIG_H

/* no configuration supported yet */

#endif /* __GFONT1_CONFIG_H */
