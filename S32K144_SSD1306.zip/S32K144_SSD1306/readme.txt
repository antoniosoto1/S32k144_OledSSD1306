readme.txt
----------
This project demonstrates using the SSD1306 LCD with I2C.
